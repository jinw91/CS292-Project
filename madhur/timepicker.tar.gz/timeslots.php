<!DOCTYPE HTML>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="styleslots.css"/>
        <script type="text/javascript" src="jsrc.js"></script>
        <script type="text/javascript"  src="slots.js">
            
        </script>
    </head>
    <body>
        
            <table cellspacing="5px">
            <tr>
                <td align="center">
                <label>
                     From:    
                </label>
                </td>
                <td>
                    <input id="from" type="date"/><br/>
                </td>
            </tr>
            <tr>
                <td align="center">
                    <label>
                    To:
                    </label>
                </td>
                <td>
                    <input type="date" id="to" /><br/>
                </td>
            </tr>
            <tr>
            <td>
            &nbsp;
            </td>
            <td align="right">
                <button id="submit"> Search </button>
            </td>
            </tr>
            </table>
            
        
        <div id="filters">
            <ul id="availableslots">
            
            
            </ul>
        </div>
    </body>
</html>
